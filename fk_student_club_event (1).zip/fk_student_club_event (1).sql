-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2026 at 09:33 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fk_student_club_event`
--

-- --------------------------------------------------------

--
-- Table structure for table `clubs`
--

CREATE TABLE `clubs` (
  `club_id` int(11) NOT NULL,
  `club_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `advisor_name` varchar(100) DEFAULT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clubs`
--

INSERT INTO `clubs` (`club_id`, `club_name`, `description`, `advisor_name`, `status`, `created_at`) VALUES
(1, 'Software Engineering Club', 'Focuses on software development, web systems, mobile applications and software projects.', 'FK UMPSA Staff', 'Active', '2026-05-14 15:15:47'),
(2, 'Cyber Security & Network Club', 'Provides cybersecurity awareness, ethical hacking, network security and competitions.', 'FK UMPSA Staff', 'Active', '2026-05-14 15:15:47'),
(3, 'Artificial Intelligence & Data Analytics Club', 'Focuses on machine learning, artificial intelligence, data analytics and predictive systems.', 'FK UMPSA Staff', 'Active', '2026-05-14 15:15:47'),
(4, 'Multimedia Technology Club', 'Specializes in multimedia systems, graphic design, animation and UI/UX development.', 'FK UMPSA Staff', 'Active', '2026-05-14 15:15:47'),
(5, 'Robotics & Internet of Things Club', 'Engages students in robotics innovation, automation systems and IoT projects.', 'FK UMPSA Staff', 'Active', '2026-05-14 15:15:47'),
(6, 'Game Development Club', 'Focuses on game design, game programming, AR/VR and interactive media development.', 'FK UMPSA Staff', 'Active', '2026-05-14 15:15:47'),
(7, 'Computing Innovation & Entrepreneurship Club', 'Encourages startup innovation, leadership, business technology and entrepreneurship.', 'FK UMPSA Staff', 'Active', '2026-05-14 15:15:47');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_id` int(11) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_date` date DEFAULT NULL,
  `event_location` varchar(255) DEFAULT NULL,
  `event_description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `memberships`
--

CREATE TABLE `memberships` (
  `membership_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `club_id` int(11) NOT NULL,
  `membership_type` enum('member','committee') DEFAULT 'member',
  `committee_role` varchar(50) DEFAULT NULL,
  `joined_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `membership_status` varchar(50) DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `memberships`
--

INSERT INTO `memberships` (`membership_id`, `user_id`, `club_id`, `membership_type`, `committee_role`, `joined_date`, `membership_status`) VALUES
(1, 3, 4, 'committee', 'Committee Member', '2026-05-12 16:00:00', 'Active'),
(10, 2, 1, 'member', '', '2026-04-30 16:00:00', 'Inactive'),
(11, 2, 1, '', NULL, '2026-05-16 19:08:36', 'Inactive'),
(12, 2, 3, '', NULL, '2026-05-16 19:33:09', 'Inactive'),
(13, 2, 2, '', NULL, '2026-05-16 19:36:46', 'Inactive'),
(14, 2, 2, '', NULL, '2026-05-16 19:42:48', 'Inactive'),
(15, 2, 1, '', NULL, '2026-05-16 20:09:38', 'Inactive'),
(16, 2, 1, '', NULL, '2026-05-16 20:13:24', 'Inactive'),
(17, 2, 2, '', NULL, '2026-05-16 20:34:01', 'Inactive'),
(18, 2, 2, '', NULL, '2026-05-16 20:46:17', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `student_id` varchar(20) DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','student','committee') NOT NULL,
  `profile_image` varchar(255) DEFAULT 'default.png',
  `reset_token` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `bio` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `student_id`, `full_name`, `email`, `phone`, `password`, `role`, `profile_image`, `reset_token`, `created_at`, `bio`) VALUES
(1, 'ADMIN001', 'FAQIHAH', 'admin@fk.com', '0123456789', 'Admin123', 'admin', 'default.png', NULL, '2026-05-13 03:34:22', NULL),
(2, 'STUDENT001', 'ATIEFFA', 'tipah123@gmail.com', '01123432323', 'Atieffa123', 'student', 'default.png', NULL, '2026-05-13 03:41:24', NULL),
(3, 'COMMITTEE001', 'MULTIMEDIA', 'committee@fk.com', '01123456789', 'Comm123', 'committee', 'default.png', NULL, '2026-05-13 04:38:47', NULL),
(8, 'CB25036', 'ANUAR', 'khaijoe846@gmail.com', '01125548054', 'Khairul123', 'admin', 'default.png', NULL, '2026-05-18 08:08:02', NULL),
(9, 'CB24059', 'RANGGES', 'rangges123@gmail.com', '011222334455', 'Rangges123', 'admin', 'default.png', NULL, '2026-05-18 08:33:12', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clubs`
--
ALTER TABLE `clubs`
  ADD PRIMARY KEY (`club_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `memberships`
--
ALTER TABLE `memberships`
  ADD PRIMARY KEY (`membership_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `club_id` (`club_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `student_id` (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clubs`
--
ALTER TABLE `clubs`
  MODIFY `club_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `memberships`
--
ALTER TABLE `memberships`
  MODIFY `membership_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `memberships`
--
ALTER TABLE `memberships`
  ADD CONSTRAINT `memberships_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `memberships_ibfk_2` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`club_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
